package com.example.song.demo;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.sql.Date;
import java.sql.Time;
import java.text.SimpleDateFormat;
import app.akexorcist.bluetotohspp.library.BluetoothSPP;
import app.akexorcist.bluetotohspp.library.BluetoothState;
import app.akexorcist.bluetotohspp.library.DeviceList;

public class MainActivity extends AppCompatActivity {

    private String uri = "http://114.205.171.60:8090/";
    private String id = "asx";
    //private int timer = 0;
    //private BluetoothSPP bt;
    Handler handler;
    TextView tvLat, tvLong, tvSpeed, tvTime;
    String time;
    double bef_lat, bef_long, cur_lat, cur_long, speed, sum_dist =0;
    CalDistance calDistance;
    GpsInfo gps;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //bt = new BluetoothSPP(this); //Initializing

        //if (!bt.isBluetoothAvailable()) { //블루투스 사용 불가
        //    Toast.makeText(getApplicationContext()
        //            , "Bluetooth is not available"
        //            , Toast.LENGTH_SHORT).show();
        //    finish();
        //}

        //setBluetooth();

        tvLat = (TextView)findViewById(R.id.tv_lat);
        tvLong = (TextView)findViewById(R.id.tv_long);
        tvSpeed = (TextView)findViewById(R.id.tv_speed);
        tvTime = (TextView)findViewById(R.id.tv_time);
        final Button btn_start = (Button)findViewById(R.id.btn_start);
        final Button btn_finish = (Button)findViewById(R.id.btn_stop);

        //final GpsInfo gps = new GpsInfo(MainActivity.this);
        btn_start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(view.getId() == R.id.btn_start){
                    ConfigGPSDB configGPSDB = new ConfigGPSDB();
                    configGPSDB.execute();
                    gps = new GpsInfo(MainActivity.this);
                   // Intent intent = new Intent(getApplicationContext(), DeviceList.class);
                   // startActivityForResult(intent, BluetoothState.REQUEST_CONNECT_DEVICE);
                    if(gps.isGetLocation()){
                       double latitude = gps.getLatitude();
                        double longitude = gps.getLongitude();
                        Log.e("위도", Double.toString(latitude));
                        Log.e("경도", Double.toString(longitude));
                        latitude = (int)(latitude * 1000000) / 1000000.0;
                        longitude = (int)(longitude * 1000000) / 1000000.0;

                        bef_lat = latitude;
                        bef_long = longitude;

                        tvLat.setText(Double.toString(latitude));
                        tvLong.setText(Double.toString(longitude));
                        setTime();
                    }
                    handler = new Handler(){
                      @Override
                      public void handleMessage(Message msg) {
                          handler.sendEmptyMessageDelayed(0, 3000);
                          //timer++;
                          //if(timer % 3 == 0) {
                              gps = new GpsInfo(MainActivity.this);
                              if (gps.isGetLocation()) {
                                  Log.e("GPS사용", "찍힘");
                                  double latitude = gps.getLatitude();
                                  double longitude = gps.getLongitude();
                                  latitude = (int)(latitude * 1000000) / 1000000.0;
                                  longitude = (int)(longitude * 1000000) / 1000000.0;
                                  cur_lat = latitude;
                                  cur_long = longitude;
                                  Log.e("위도", Double.toString(cur_lat));
                                  Log.e("경도", Double.toString(cur_long));
                                  Log.e("이전위도", Double.toString(bef_lat));
                                  Log.e("이전경도", Double.toString(bef_long));
                                  Log.e("위도", Double.toString(latitude));
                                  Log.e("경도", Double.toString(longitude));
                                  calDistance = new CalDistance(bef_lat, bef_long, cur_lat, cur_long);
                                  double dist = calDistance.getDistance();
                                  dist = (int)(dist*100) / 100.0;
                                  sum_dist += dist;
                                  speed = dist / 3600;
                                  speed = (int)(speed * 100) / 100.0;

                                  //double x = (cur_lat - bef_lat);
                                  //double y = (cur_long - bef_long);
                                  //speed = ((x * x) + (y * y)) / 3000;

                                  bef_lat = cur_lat;
                                  bef_long = cur_long;

                                  tvLat.setText(Double.toString(latitude));
                                  tvLong.setText(Double.toString(longitude));
                                  tvSpeed.setText(Double.toString(speed));
                                  setTime();
                                  DataSend();
                              }

                      }
                    };
                    handler.sendEmptyMessage(0);
                }
            }
        });

        btn_finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (view.getId() == R.id.btn_stop) {
                    Log.e("GPS 중지", "중지!");
                   // if (bt.getServiceState() == BluetoothState.STATE_CONNECTED) {
                   //     bt.disconnect();
                   // }
                    handler.removeMessages(0);
                }
            }
        });

    }
    public void setTime(){
        long now = System.currentTimeMillis();
        Date date = new Date(now);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        time = simpleDateFormat.format(date);
        tvTime.setText(time);
    }
    @Override
    public void onDestroy() {
        super.onDestroy();
        handler.removeMessages(0);
        //bt.stopService(); //블루투스 중지
    }
    @Override
    public void onPause(){
        super.onPause();
        handler.removeMessages(0);
    }

    public void DataSend(){
        WriteGPSDB writeGPSDB = new WriteGPSDB();
        writeGPSDB.execute();
    }

/*
    public void setBluetooth(){
        bt.setOnDataReceivedListener(new BluetoothSPP.OnDataReceivedListener() { //데이터 수신
            public void onDataReceived(byte[] data, String message) {
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
            }
        });

        bt.setBluetoothConnectionListener(new BluetoothSPP.BluetoothConnectionListener() { //연결됐을 때
            public void onDeviceConnected(String name, String address) {
                Toast.makeText(getApplicationContext()
                        , "Connected to " + name + "\n" + address
                        , Toast.LENGTH_SHORT).show();
            }

            public void onDeviceDisconnected() { //연결해제
                Toast.makeText(getApplicationContext()
                        , "Connection lost", Toast.LENGTH_SHORT).show();
            }

            public void onDeviceConnectionFailed() { //연결실패
                Toast.makeText(getApplicationContext()
                        , "Unable to connect", Toast.LENGTH_SHORT).show();
            }
        });
    }
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == BluetoothState.REQUEST_CONNECT_DEVICE) {
            if (resultCode == Activity.RESULT_OK)
                bt.connect(data);
        } else if (requestCode == BluetoothState.REQUEST_ENABLE_BT) {
            if (resultCode == Activity.RESULT_OK) {
                bt.setupService();
                bt.startService(BluetoothState.DEVICE_OTHER);
            } else {
                Toast.makeText(getApplicationContext()
                        , "Bluetooth was not enabled."
                        , Toast.LENGTH_SHORT).show();
                finish();
            }
        }
    }
*/
    public class ConfigGPSDB extends AsyncTask<Void, Integer, Void> {

        String data = "";
        @Override
        protected Void doInBackground(Void... unused) {

            /* 인풋 파라메터값 생성 */
            String param = "u_id=" + id  + "";

            Log.e("POST",param);
            Log.e("url1", uri);
            try {
                /* 서버연결 */
                URL url = new URL(uri + "gpslist.php");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                conn.setRequestMethod("POST");
                conn.setDoInput(true);
                conn.connect();

                /* 안드로이드 -> 서버 파라메터값 전달 */
                OutputStream outs = conn.getOutputStream();
                outs.write(param.getBytes("UTF-8"));
                outs.flush();
                outs.close();
                Log.e("andr->serv","finish");

                /* 서버 -> 안드로이드 파라메터값 전달 */
                InputStream is = null;
                BufferedReader in = null;

                is = conn.getInputStream();
                in = new BufferedReader(new InputStreamReader(is), 8 * 1024);
                data = in.readLine();
                Log.e("data",data);
                in.close();
                /* 서버에서 응답 */

            } catch (MalformedURLException e) {
                Log.e("malformed", "erroer!");
                e.printStackTrace();
            } catch (IOException e) {
                Log.e("IOException", "erroer!");
                e.printStackTrace();
            }

            return null;
        }


        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            Log.e("DATA",data);
        }

    }


    public class WriteGPSDB extends AsyncTask<Void, Integer, Void> {

        String data = "";
        @Override
        protected Void doInBackground(Void... unused) {

            /* 인풋 파라메터값 생성 */
            String param = "u_id=" + id + "&u_lat=" + cur_lat + "&u_long=" + cur_long
                    + "&u_speed=" + speed + "&u_time=" + time + "" + "&u_dist=" + sum_dist + "";

            Log.e("POST",param);
            Log.e("url2", uri);
            try {
                /* 서버연결 */
                URL url = new URL(uri + "writegps.php");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                conn.setRequestMethod("POST");
                conn.setDoInput(true);
                conn.connect();

                /* 안드로이드 -> 서버 파라메터값 전달 */
                OutputStream outs = conn.getOutputStream();
                outs.write(param.getBytes("UTF-8"));
                outs.flush();
                outs.close();
                Log.e("andr->serv","finish");

                /* 서버 -> 안드로이드 파라메터값 전달 */
                InputStream is = null;
                BufferedReader in = null;

                is = conn.getInputStream();
                in = new BufferedReader(new InputStreamReader(is), 8 * 1024);
                data = in.readLine();
                Log.e("data",data);
                in.close();
                /* 서버에서 응답 */
                conn.disconnect();

            } catch (MalformedURLException e) {
                Log.e("malformed", "erroer!");
                e.printStackTrace();
            } catch (IOException e) {
                Log.e("IOException", "erroer!");
                e.printStackTrace();
            }

            return null;
        }


        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            Log.e("DATA",data);

        }

    }

}
