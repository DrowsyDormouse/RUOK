package com.example.ch555.myapplication;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.TextView;

import java.util.logging.Handler;

public class Adsearch extends AppCompatActivity{

    private WebView webView;
    private TextView adresult;
    private Handler handler;

    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.adsearch);

        adresult =(TextView)findViewById(R.id.adresult);

        init_webView();

        handler = new Hander();
    }

    @SuppressLint("JavascriptInterface")
    private void init_webView() {

        webView = (WebView)findViewById(R.id.webview);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        webView.addJavascriptInterface(new AndroidBridge(), "TestApp");
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("http://codeman77.ivyro.net/getAddress.php");
    }

    private class AndroidBridge{
        @JavascriptInterface
        public void setAddress(final String arg1, final String arg2, final String arg3){
            handler.post(new Runnable(){
                public void run(){
                    @Override
                            adresult.setText(String.format("(%s) %s %s",arg1,arg2,arg3);
                    init_webView();
                }
            });
        }
    }
}
